
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Contraseña</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="card w-100" style="max-width: 400px;">
        <h3 class="text-center text-danger mb-4">Recuperar Contraseña</h3>
        <form onsubmit="mostrarAlerta(); return false;">
            <div class="mb-3">
                <label class="form-label">Correo electrónico</label>
                <input type="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-danger w-100">Enviar enlace</button>
            <a href="index.php" class="d-block text-center mt-2 text-decoration-none">Volver al inicio</a>
        </form>
    </div>

    <script>
        function mostrarAlerta() {
            Swal.fire({
                icon: 'success',
                title: 'Correo enviado',
                text: 'Si el correo está registrado, recibirás un enlace para restablecer tu contraseña.',
            });
        }
    </script>
</body>
</html>
