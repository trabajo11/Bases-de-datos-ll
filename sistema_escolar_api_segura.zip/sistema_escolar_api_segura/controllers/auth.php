
<?php
session_start();
require '../config/db.php';

$correo = $_POST['correo'] ?? '';
$password = $_POST['password'] ?? '';

// Verificar si el usuario existe
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE correo = ?");
$stmt->execute([$correo]);
$usuario = $stmt->fetch();

if (!$usuario) {
    echo json_encode(["success" => false, "message" => "Correo no registrado"]);
    exit();
}

// Verificar si está bloqueado
$stmt = $pdo->prepare("SELECT * FROM usuarios_bloqueados WHERE id_usuario = ?");
$stmt->execute([$usuario['id_usuario']]);
if ($stmt->fetch()) {
    echo json_encode(["success" => false, "message" => "Usuario bloqueado"]);
    exit();
}

// Verificar contraseña segura
if (password_verify($password, $usuario['password'])) {
    $pdo->prepare("INSERT INTO intentos_login (id_usuario, exito) VALUES (?, 1)")->execute([$usuario['id_usuario']]);
    $_SESSION['usuario_id'] = $usuario['id_usuario'];
    $_SESSION['usuario_nombre'] = $usuario['nombre'];
    $_SESSION['usuario_rol'] = $usuario['tipo'];
    echo json_encode(["success" => true]);
} else {
    $pdo->prepare("INSERT INTO intentos_login (id_usuario, exito) VALUES (?, 0)")->execute([$usuario['id_usuario']]);

    // Contar intentos fallidos en los últimos 5 minutos
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM intentos_login WHERE id_usuario = ? AND exito = 0 AND fecha >= NOW() - INTERVAL 5 MINUTE");
    $stmt->execute([$usuario['id_usuario']]);
    $fallos = $stmt->fetchColumn();

    if ($fallos >= 3) {
        $pdo->prepare("INSERT INTO usuarios_bloqueados (id_usuario) VALUES (?)")->execute([$usuario['id_usuario']]);
        echo json_encode(["success" => false, "message" => "Usuario bloqueado tras varios intentos"]);
    } else {
        echo json_encode(["success" => false, "message" => "Contraseña incorrecta"]);
    }
}
?>
