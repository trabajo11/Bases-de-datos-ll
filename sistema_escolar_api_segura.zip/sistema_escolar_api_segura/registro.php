
<?php
require 'config/db.php';

$mensaje = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $correo = $_POST["correo"];
    $password = $_POST["password"];
    $confirmar = $_POST["confirmar"];

    if ($password !== $confirmar) {
        $mensaje = "Las contraseñas no coinciden.";
    } else {
        $clave = password_hash($password, PASSWORD_DEFAULT);
        $rol = 'Estudiante';

        $verificar = $pdo->prepare("SELECT * FROM usuarios WHERE correo = ?");
        $verificar->execute([$correo]);
        if ($verificar->rowCount() > 0) {
            $mensaje = "Este correo ya está registrado.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, tipo) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$nombre, $apellido, $correo, $clave, $rol])) {
                $mensaje = "Usuario registrado exitosamente.";
            } else {
                $mensaje = "Error al registrar. Intenta de nuevo.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrarse - Colegio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #6a11cb, #2575fc);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="card w-100" style="max-width: 450px;">
        <h3 class="text-center mb-4 text-primary">Crear nueva cuenta</h3>
        <?php if ($mensaje): ?>
            <div class="alert alert-info"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input type="text" name="nombre" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Apellido</label>
                <input type="text" name="apellido" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Correo electrónico</label>
                <input type="email" name="correo" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Confirmar contraseña</label>
                <input type="password" name="confirmar" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Registrarme</button>
            <a href="index.php" class="d-block text-center mt-2 text-decoration-none">Ya tengo una cuenta</a>
        </form>
    </div>
</body>
</html>
