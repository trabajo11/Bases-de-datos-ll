
<?php
require 'config.php';
header('Content-Type: application/json');

// Verificar token de acceso
$token = $_GET['token'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE api_token = ?");
$stmt->execute([$token]);
$usuario = $stmt->fetch();

if (!$usuario) {
    http_response_code(403);
    echo json_encode(["error" => "Token inválido o no autorizado."]);
    exit;
}

// Determinar recurso solicitado
$recurso = $_GET['recurso'] ?? '';

switch ($recurso) {
    case 'usuarios':
        $stmt = $pdo->query("SELECT id_usuario, nombre, apellido, correo, tipo FROM usuarios");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'notas':
        $id_usuario = $_GET['id_usuario'] ?? null;
        if (!$id_usuario) {
            echo json_encode(["error" => "Falta parámetro id_usuario"]);
            break;
        }
        $stmt = $pdo->prepare("SELECT n.id_nota, c.nombre_curso, n.nota
                               FROM notas n
                               JOIN cursos c ON n.id_curso = c.id_curso
                               WHERE n.id_usuario = ?");
        $stmt->execute([$id_usuario]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    default:
        echo json_encode(["error" => "Recurso no encontrado"]);
        break;
}
?>
