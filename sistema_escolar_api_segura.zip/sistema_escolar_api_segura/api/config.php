
<?php
define('API_KEY', '123456789SECRET'); // clave de acceso básica
require_once '../config/db.php';
?>
