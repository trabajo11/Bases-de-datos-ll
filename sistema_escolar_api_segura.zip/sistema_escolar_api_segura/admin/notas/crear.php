<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

$estudiantes = $pdo->query("SELECT id_usuario, nombre, apellido FROM usuarios WHERE tipo = 'Estudiante'")->fetchAll();
$cursos = $pdo->query("SELECT * FROM cursos")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = $_POST['usuario'];
    $id_curso = $_POST['curso'];
    $nota = $_POST['nota'];
    $stmt = $pdo->prepare("INSERT INTO notas (id_usuario, id_curso, nota) VALUES (?, ?, ?)");
    $stmt->execute([$id_usuario, $id_curso, $nota]);
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Nota</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Agregar Nota</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Estudiante</label>
      <select name="usuario" class="form-select" required>
        <?php foreach ($estudiantes as $e): ?>
        <option value="<?= $e['id_usuario'] ?>"><?= $e['nombre'] . ' ' . $e['apellido'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Curso</label>
      <select name="curso" class="form-select" required>
        <?php foreach ($cursos as $c): ?>
        <option value="<?= $c['id_curso'] ?>"><?= $c['nombre_curso'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Nota (0-100)</label>
      <input type="number" name="nota" class="form-control" step="0.1" min="0" max="100" required>
    </div>
    <button type="submit" class="btn btn-success">Guardar</button>
    <a href="index.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>