<?php
require '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id_usuario'] ?? 0;
    $pdo->prepare("DELETE FROM usuarios_bloqueados WHERE id_usuario = ?")->execute([$id]);
    echo "Usuario desbloqueado";
}