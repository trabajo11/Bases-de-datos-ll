<?php
require '../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../index.php"); exit(); }

$activos = $pdo->query("SELECT * FROM usuarios WHERE id_usuario NOT IN (SELECT id_usuario FROM usuarios_bloqueados)")->fetchAll();
$bloqueados = $pdo->query("SELECT u.*, ub.fecha_bloqueo FROM usuarios u JOIN usuarios_bloqueados ub ON u.id_usuario = ub.id_usuario")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Usuarios</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h3>Usuarios Activos</h3>
    <table class="table table-striped">
      <thead><tr><th>Nombre</th><th>Correo</th><th>Tipo</th></tr></thead>
      <tbody>
        <?php foreach ($activos as $u): ?>
        <tr><td><?= $u['nombre'] . ' ' . $u['apellido'] ?></td><td><?= $u['correo'] ?></td><td><?= $u['tipo'] ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h3 class="mt-5">Usuarios Bloqueados</h3>
    <table class="table table-bordered">
      <thead><tr><th>Nombre</th><th>Correo</th><th>Fecha bloqueo</th><th>Acción</th></tr></thead>
      <tbody>
        <?php foreach ($bloqueados as $u): ?>
        <tr>
          <td><?= $u['nombre'] . ' ' . $u['apellido'] ?></td>
          <td><?= $u['correo'] ?></td>
          <td><?= $u['fecha_bloqueo'] ?></td>
          <td><button class="btn btn-warning btn-sm" onclick="desbloquear(<?= $u['id_usuario'] ?>)">Desbloquear</button></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <a href="panel.php" class="btn btn-secondary mt-3">Volver al Panel</a>
  </div>

  <script>
    function desbloquear(id) {
      fetch('desbloquear.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id_usuario=' + id
      })
      .then(r => r.text())
      .then(resp => {
        Swal.fire('Desbloqueado', resp, 'success').then(() => location.reload());
      });
    }
  </script>
</body>
</html>