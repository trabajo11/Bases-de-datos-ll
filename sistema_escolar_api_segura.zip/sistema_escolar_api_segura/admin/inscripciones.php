<?php
require '../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../index.php"); exit(); }

$datos = $pdo->query("SELECT * FROM vistainscripciones")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Inscripciones</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Inscripciones</h2>
  <table class="table table-striped">
    <thead><tr><th>ID</th><th>Nombre</th><th>Curso</th><th>Fecha</th></tr></thead>
    <tbody>
      <?php foreach ($datos as $row): ?>
      <tr>
        <td><?= $row['id_inscripcion'] ?></td>
        <td><?= $row['nombre'] . ' ' . $row['apellido'] ?></td>
        <td><?= $row['nombre_curso'] ?></td>
        <td><?= $row['fecha_inscripcion'] ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a href="panel.php" class="btn btn-secondary">Volver</a>
</div>
</body>
</html>