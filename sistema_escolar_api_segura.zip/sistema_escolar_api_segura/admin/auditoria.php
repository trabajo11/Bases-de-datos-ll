<?php
require '../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../index.php"); exit(); }

$logs = $pdo->query("SELECT * FROM auditoria ORDER BY fecha DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Auditoría</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Registro de Auditoría</h2>
  <table class="table table-bordered">
    <thead><tr><th>ID</th><th>Tabla</th><th>Acción</th><th>ID Registro</th><th>Fecha</th></tr></thead>
    <tbody>
      <?php foreach ($logs as $log): ?>
      <tr>
        <td><?= $log['id_auditoria'] ?></td>
        <td><?= $log['tabla_afectada'] ?></td>
        <td><?= $log['accion'] ?></td>
        <td><?= $log['id_registro'] ?></td>
        <td><?= $log['fecha'] ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a href="panel.php" class="btn btn-secondary">Volver</a>
</div>
</body>
</html>