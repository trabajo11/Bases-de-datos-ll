<?php
require '../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../index.php"); exit(); }

// Totales
$usuarios = $pdo->query("SELECT tipo, COUNT(*) AS total FROM usuarios GROUP BY tipo")->fetchAll();
$cursos = $pdo->query("SELECT COUNT(*) FROM cursos")->fetchColumn();
$programas = $pdo->query("SELECT COUNT(*) FROM programas")->fetchColumn();
$notas = $pdo->query("SELECT COUNT(*) FROM notas")->fetchColumn();
$bloqueados = $pdo->query("SELECT COUNT(*) FROM usuarios_bloqueados")->fetchColumn();

// Inscripciones por curso
$inscripciones = $pdo->query("
  SELECT c.nombre_curso, COUNT(i.id_inscripcion) AS total
  FROM cursos c
  LEFT JOIN inscripciones i ON c.id_curso = i.id_curso
  GROUP BY c.id_curso
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2 class="mb-4 text-primary">Dashboard del Administrador</h2>

  <div class="row mb-4">
    <div class="col-md-3">
      <div class="card text-bg-primary mb-3">
        <div class="card-body">
          <h5 class="card-title">Usuarios</h5>
          <?php foreach ($usuarios as $u): ?>
            <p><?= $u['tipo'] ?>: <strong><?= $u['total'] ?></strong></p>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-bg-success mb-3">
        <div class="card-body">
          <h5 class="card-title">Cursos</h5>
          <p><strong><?= $cursos ?></strong></p>
          <h6 class="card-subtitle">Programas: <?= $programas ?></h6>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-bg-warning mb-3">
        <div class="card-body">
          <h5 class="card-title">Notas</h5>
          <p><strong><?= $notas ?></strong></p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-bg-danger mb-3">
        <div class="card-body">
          <h5 class="card-title">Usuarios Bloqueados</h5>
          <p><strong><?= $bloqueados ?></strong></p>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-6">
      <canvas id="graficaUsuarios"></canvas>
    </div>
    <div class="col-md-6">
      <canvas id="graficaInscripciones"></canvas>
    </div>
  </div>

  <a href="panel.php" class="btn btn-secondary mt-4">Volver al Panel</a>
</div>

<script>
  const ctx1 = document.getElementById('graficaUsuarios');
  new Chart(ctx1, {
    type: 'doughnut',
    data: {
      labels: [<?php foreach ($usuarios as $u) echo "'{$u['tipo']}',"; ?>],
      datasets: [{
        label: 'Distribución de Usuarios',
        data: [<?php foreach ($usuarios as $u) echo "{$u['total']},"; ?>],
        backgroundColor: ['#0d6efd', '#198754', '#ffc107']
      }]
    }
  });

  const ctx2 = document.getElementById('graficaInscripciones');
  new Chart(ctx2, {
    type: 'bar',
    data: {
      labels: [<?php foreach ($inscripciones as $i) echo "'{$i['nombre_curso']}',"; ?>],
      datasets: [{
        label: 'Inscripciones por Curso',
        data: [<?php foreach ($inscripciones as $i) echo "{$i['total']},"; ?>],
        backgroundColor: '#6610f2'
      }]
    }
  });
</script>
</body>
</html>
