<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

$estudiantes = $pdo->query("SELECT * FROM usuarios WHERE tipo = 'Estudiante'")->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <!-- DataTables -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

  <meta charset="UTF-8">
  <title>Estudiantes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="container mt-5">
  <h2>Estudiantes</h2>
  <a href="crear.php" class="btn btn-primary mb-3">Nuevo Estudiante</a>
  <table class="table table-striped">
    <thead><tr><th>Nombre</th><th>Correo</th><th>Acciones</th></tr></thead>
    <tbody>
      <?php foreach ($estudiantes as $e): ?>
      <tr>
        <td><?= $e['nombre'] . ' ' . $e['apellido'] ?></td>
        <td><?= $e['correo'] ?></td>
        <td>
          <a href="editar.php?id=<?= $e['id_usuario'] ?>" class="btn btn-warning btn-sm">Editar</a>
          <button class="btn btn-danger btn-sm" onclick="eliminar(<?= $e['id_usuario'] ?>)">Eliminar</button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a href="../panel.php" class="btn btn-secondary">Volver</a>
</div>

<script>
function eliminar(id) {
  Swal.fire({
    title: '¿Estás seguro?',
    text: "Esta acción no se puede deshacer",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Sí, eliminar',
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = "eliminar.php?id=" + id;
    }
  });
}
</script>

<!-- DataTables Scripts -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    let table = document.querySelector('table');
    if (table) {
      new DataTable(table, {
        dom: 'Bfrtip',
        buttons: ['copy', 'excel', 'csv', 'pdf', 'print'],
        language: {
          url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
        }
      });
    }
  });
</script>

</body>
</html>