<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$id]);
$docente = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ? WHERE id_usuario = ?");
    $stmt->execute([$nombre, $apellido, $correo, $id]);
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Docente</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Editar Docente</h2>
  <form method="POST">
    <div class="mb-3"><label>Nombre</label><input type="text" name="nombre" class="form-control" value="<?= $docente['nombre'] ?>" required></div>
    <div class="mb-3"><label>Apellido</label><input type="text" name="apellido" class="form-control" value="<?= $docente['apellido'] ?>" required></div>
    <div class="mb-3"><label>Correo</label><input type="email" name="correo" class="form-control" value="<?= $docente['correo'] ?>" required></div>
    <button type="submit" class="btn btn-primary">Actualizar</button>
    <a href="index.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>