<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

$id_docente = $_GET['id'] ?? 0;

$cursos = $pdo->query("SELECT * FROM cursos")->fetchAll();
$asignados = $pdo->prepare("SELECT id_curso FROM docentecurso WHERE id_docente = ?");
$asignados->execute([$id_docente]);
$ids_asignados = array_column($asignados->fetchAll(), 'id_curso');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cursos_sel = $_POST['cursos'] ?? [];
    $pdo->prepare("DELETE FROM docentecurso WHERE id_docente = ?")->execute([$id_docente]);
    foreach ($cursos_sel as $id_curso) {
        $pdo->prepare("INSERT INTO docentecurso (id_docente, id_curso) VALUES (?, ?)")->execute([$id_docente, $id_curso]);
    }
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Asignar Cursos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Asignar Cursos al Docente</h2>
  <form method="POST">
    <?php foreach ($cursos as $c): ?>
    <div class="form-check">
      <input class="form-check-input" type="checkbox" name="cursos[]" value="<?= $c['id_curso'] ?>" <?= in_array($c['id_curso'], $ids_asignados) ? 'checked' : '' ?>>
      <label class="form-check-label"><?= $c['nombre_curso'] ?></label>
    </div>
    <?php endforeach; ?>
    <button type="submit" class="btn btn-primary mt-3">Guardar</button>
    <a href="index.php" class="btn btn-secondary mt-3">Cancelar</a>
  </form>
</div>
</body>
</html>