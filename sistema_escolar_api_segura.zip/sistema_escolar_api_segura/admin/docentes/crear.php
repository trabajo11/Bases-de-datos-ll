<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $password = $_POST['password'];
    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, tipo) VALUES (?, ?, ?, ?, 'Docente')");
    $stmt->execute([$nombre, $apellido, $correo, $password]);
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Nuevo Docente</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Registrar Docente</h2>
  <form method="POST">
    <div class="mb-3"><label>Nombre</label><input type="text" name="nombre" class="form-control" required></div>
    <div class="mb-3"><label>Apellido</label><input type="text" name="apellido" class="form-control" required></div>
    <div class="mb-3"><label>Correo</label><input type="email" name="correo" class="form-control" required></div>
    <div class="mb-3"><label>Contraseña</label><input type="text" name="password" class="form-control" required></div>
    <button type="submit" class="btn btn-success">Guardar</button>
    <a href="index.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>