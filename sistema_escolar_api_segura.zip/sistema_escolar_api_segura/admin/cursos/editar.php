<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM cursos WHERE id_curso = ?");
$stmt->execute([$id]);
$curso = $stmt->fetch();

$programas = $pdo->query("SELECT * FROM programas")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $programa = $_POST['programa'];
    $stmt = $pdo->prepare("UPDATE cursos SET nombre_curso = ?, id_programa = ? WHERE id_curso = ?");
    $stmt->execute([$nombre, $programa, $id]);
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Curso</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Editar Curso</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Nombre del Curso</label>
      <input type="text" name="nombre" class="form-control" value="<?= $curso['nombre_curso'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Programa Académico</label>
      <select name="programa" class="form-select" required>
        <?php foreach ($programas as $p): ?>
        <option value="<?= $p['id_programa'] ?>" <?= ($curso['id_programa'] == $p['id_programa']) ? 'selected' : '' ?>>
          <?= $p['nombre_programa'] ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Actualizar</button>
    <a href="index.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>