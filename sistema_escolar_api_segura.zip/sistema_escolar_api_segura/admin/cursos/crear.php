<?php
require '../../config/db.php';
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../../index.php"); exit(); }

$programas = $pdo->query("SELECT * FROM programas")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $programa = $_POST['programa'];
    $stmt = $pdo->prepare("INSERT INTO cursos (nombre_curso, id_programa) VALUES (?, ?)");
    $stmt->execute([$nombre, $programa]);
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Nuevo Curso</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Registrar Curso</h2>
  <form method="POST">
    <div class="mb-3">
      <label>Nombre del Curso</label>
      <input type="text" name="nombre" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Programa Académico</label>
      <select name="programa" class="form-select" required>
        <?php foreach ($programas as $p): ?>
        <option value="<?= $p['id_programa'] ?>"><?= $p['nombre_programa'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-success">Guardar</button>
    <a href="index.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>