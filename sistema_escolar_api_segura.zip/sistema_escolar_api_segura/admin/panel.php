<?php
session_start();
if (!isset($_SESSION['usuario_id'])) { header("Location: ../index.php"); exit(); }
$nombre_usuario = $_SESSION['usuario_nombre'] ?? 'Administrador';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel | Colegio San Gabriel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      margin: 0;
      background-color: #f5f7fa;
      font-family: 'Segoe UI', sans-serif;
    }
    .sidebar {
      height: 100vh;
      position: fixed;
      width: 220px;
      background-color: #002244;
      color: white;
      padding-top: 20px;
    }
    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      padding: 12px 20px;
      font-weight: 500;
    }
    .sidebar a:hover, .sidebar a.active {
      background-color: #014080;
    }
    .header {
      margin-left: 220px;
      background-color: white;
      padding: 20px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
    .main {
      margin-left: 220px;
      padding: 30px;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.06);
      transition: all 0.3s ease;
    }
    .card:hover {
      transform: translateY(-3px);
    }
  </style>
</head>
<body>

<div class="sidebar">
  <h5 class="text-center mb-4">🎓 Colegio San Gabriel</h5>
  <a href="panel.php" class="active"><i class="bi bi-speedometer2"></i> Panel</a>
  <a href="dashboard.php"><i class="bi bi-graph-up-arrow"></i> Dashboard</a>
  <a href="usuarios.php"><i class="bi bi-people"></i> Usuarios</a>
  <a href="docentes/index.php"><i class="bi bi-person-badge-fill"></i> Docentes</a>
  <a href="estudiantes/index.php"><i class="bi bi-mortarboard-fill"></i> Estudiantes</a>
  <a href="cursos/index.php"><i class="bi bi-book"></i> Cursos</a>
  <a href="notas/index.php"><i class="bi bi-pencil-fill"></i> Notas</a>
  <a href="inscripciones.php"><i class="bi bi-clipboard-check-fill"></i> Inscripciones</a>
  <a href="auditoria.php"><i class="bi bi-clipboard-data"></i> Auditoría</a>
  <a href="../logout.php" class="text-danger"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a>
</div>

<div class="header">
  <div class="d-flex justify-content-between align-items-center">
    <h4 class="mb-0">Panel Principal</h4>
    <div class="text-muted">👋 Bienvenido, <strong><?= $nombre_usuario ?></strong></div>
  </div>
</div>

<div class="main">
  <div class="row g-4">
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-person-fill fs-2 text-primary"></i>
        <h6 class="mt-2">Usuarios</h6>
        <a href="usuarios.php" class="stretched-link"></a>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-book fs-2 text-success"></i>
        <h6 class="mt-2">Cursos</h6>
        <a href="cursos/index.php" class="stretched-link"></a>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-mortarboard fs-2 text-warning"></i>
        <h6 class="mt-2">Estudiantes</h6>
        <a href="estudiantes/index.php" class="stretched-link"></a>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-person-badge fs-2 text-info"></i>
        <h6 class="mt-2">Docentes</h6>
        <a href="docentes/index.php" class="stretched-link"></a>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-pencil-square fs-2 text-dark"></i>
        <h6 class="mt-2">Notas</h6>
        <a href="notas/index.php" class="stretched-link"></a>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-clipboard-check fs-2 text-success"></i>
        <h6 class="mt-2">Inscripciones</h6>
        <a href="inscripciones.php" class="stretched-link"></a>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-4 text-center bg-light">
        <i class="bi bi-bar-chart-line fs-2 text-secondary"></i>
        <h6 class="mt-2">Dashboard</h6>
        <a href="dashboard.php" class="stretched-link"></a>
      </div>
    </div>
  </div>
</div>

</body>
</html>
