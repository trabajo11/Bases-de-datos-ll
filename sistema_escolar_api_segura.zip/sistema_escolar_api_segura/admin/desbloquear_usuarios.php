
<?php
session_start();
require '../config/db.php';

// Solo permitir acceso si el usuario es administrador
if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'Administrativo') {
    header('Location: ../index.php');
    exit();
}

// Si se envía solicitud para desbloquear
if (isset($_GET['desbloquear'])) {
    $id = $_GET['desbloquear'];
    $stmt = $pdo->prepare("DELETE FROM usuarios_bloqueados WHERE id_usuario = ?");
    $stmt->execute([$id]);
    header("Location: desbloquear_usuarios.php");
    exit();
}

// Obtener usuarios bloqueados
$stmt = $pdo->query("
    SELECT ub.id_usuario, u.nombre, u.apellido, u.correo, ub.fecha_bloqueo 
    FROM usuarios_bloqueados ub
    JOIN usuarios u ON ub.id_usuario = u.id_usuario
");
$bloqueados = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Desbloquear Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h3 class="mb-4 text-primary">Usuarios Bloqueados</h3>
        <?php if (count($bloqueados) === 0): ?>
            <div class="alert alert-success">No hay usuarios bloqueados actualmente.</div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Fecha de bloqueo</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bloqueados as $usuario): ?>
                        <tr>
                            <td><?= htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']) ?></td>
                            <td><?= htmlspecialchars($usuario['correo']) ?></td>
                            <td><?= htmlspecialchars($usuario['fecha_bloqueo']) ?></td>
                            <td>
                                <a href="?desbloquear=<?= $usuario['id_usuario'] ?>" class="btn btn-success btn-sm">
                                    Desbloquear
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <a href="panel.php" class="btn btn-secondary mt-3">Volver al Panel</a>
    </div>
</body>
</html>
