<?php
session_start();
header("Location: admin/panel.php");
exit();