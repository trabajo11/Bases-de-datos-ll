<?php
session_start();
include 'db.php';

$ip = $_SERVER['REMOTE_ADDR'];
$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = md5($_POST['password']);

  // Verifica IP bloqueada
  $check = $conn->prepare("SELECT ip FROM ip_bloqueadas WHERE ip = ?");
  $check->bind_param("s", $ip);
  $check->execute();
  if ($check->get_result()->num_rows > 0) {
    die("<h3 style='text-align:center;'>🚫 Esta IP está bloqueada</h3>");
  }

  $stmt = $conn->prepare("SELECT * FROM usuarios WHERE username = ? AND password = ?");
  $stmt->bind_param("ss", $username, $password);
  $stmt->execute();
  $res = $stmt->get_result();
  $success = ($res->num_rows === 1);

  // Loguear intento
  $log = $conn->prepare("INSERT INTO intentos_login (ip, username, exito) VALUES (?, ?, ?)");
  $log->bind_param("ssi", $ip, $username, $success);
  $log->execute();

  if ($success) {
    $user = $res->fetch_assoc();
    $_SESSION['usuario'] = $user['username'];
    $_SESSION['rol'] = $user['rol'];
    echo "<script>
      document.addEventListener('DOMContentLoaded', () => {
        const btn = document.getElementById('loginBtn');
        btn.innerHTML = '<i class=\"fas fa-check-circle\"></i> ¡Acceso permitido!';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-success');
        setTimeout(() => {
          window.location.href = 'dashboard.php';
        }, 1500);
      });
    </script>";
  } else {
    $fallos = $conn->query("SELECT COUNT(*) as total FROM intentos_login WHERE ip = '$ip' AND exito = 0 AND fecha >= NOW() - INTERVAL 10 MINUTE")->fetch_assoc()['total'];
    if ($fallos >= 5) {
      $conn->query("INSERT IGNORE INTO ip_bloqueadas (ip) VALUES ('$ip')");
      die("<h3>🚫 IP bloqueada por múltiples intentos</h3>");
    }
    $error = "❌ Usuario o contraseña incorrectos.";
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login - Tech Solution</title>
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/a2e0f1f5fd.js" crossorigin="anonymous"></script>
  <style>
    body {
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-card {
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 5px 30px rgba(0,0,0,0.2);
      width: 100%;
      max-width: 400px;
      animation: slideIn 0.5s ease-out;
    }
    .login-card img {
      width: 80px;
      height: auto;
    }
    @keyframes slideIn {
      from { transform: translateY(30px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
  </style>
</head>
<body>

  <div class="login-card">
    <div class="text-center mb-3">
      <img src="img/logo.png" alt="Logo">
      <h4 class="mt-2 text-primary">Tech Solution</h4>
    </div>

    <form method="POST" id="loginForm">
      <div class="form-floating mb-3">
        <input type="text" class="form-control" name="username" id="username" placeholder="Usuario" required>
        <label for="username">Usuario</label>
      </div>

      <div class="form-floating mb-3 position-relative">
        <input type="password" class="form-control" name="password" id="password" placeholder="Contraseña" required>
        <label for="password">Contraseña</label>
        <span class="position-absolute top-50 end-0 translate-middle-y pe-3" style="cursor:pointer;" onclick="togglePassword()">
          <i class="fas fa-eye" id="eye"></i>
        </span>
      </div>

      <div class="form-check mb-3">
        <input class="form-check-input" type="checkbox" id="remember">
        <label class="form-check-label" for="remember">Recordarme</label>
      </div>

      <button id="loginBtn" type="submit" class="btn btn-primary w-100">
        <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
      </button>

      <?php if ($error): ?>
        <div class="alert alert-danger mt-3 animate__animated animate__shakeX"><?= $error ?></div>
      <?php endif; ?>
    </form>
  </div>

  <script>
    function togglePassword() {
      const pass = document.getElementById("password");
      const eye = document.getElementById("eye");
      if (pass.type === "password") {
        pass.type = "text";
        eye.classList.remove("fa-eye");
        eye.classList.add("fa-eye-slash");
      } else {
        pass.type = "password";
        eye.classList.remove("fa-eye-slash");
        eye.classList.add("fa-eye");
      }
    }
  </script>
</body>
</html>
