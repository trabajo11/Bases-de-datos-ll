<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

include '../db.php';

// Si el admin presiona "desbloquear"
if (isset($_GET['ip'])) {
    $ip = $_GET['ip'];
    $stmt = $conn->prepare("DELETE FROM ip_bloqueadas WHERE ip = ?");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
    header("Location: desbloquear_ip.php?success=1");
    exit;
}

$ips = $conn->query("SELECT * FROM ip_bloqueadas ORDER BY fecha_bloqueo DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Desbloquear IP - Admin</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h3>🛡️ IPs Bloqueadas</h3>

  <?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">IP desbloqueada correctamente.</div>
  <?php endif; ?>

  <?php if ($ips->num_rows === 0): ?>
    <div class="alert alert-info">No hay IPs bloqueadas actualmente.</div>
  <?php else: ?>
    <table class="table table-bordered">
      <thead class="table-dark">
        <tr>
          <th>IP</th>
          <th>Fecha de Bloqueo</th>
          <th>Acción</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($ip = $ips->fetch_assoc()): ?>
        <tr>
          <td><?= $ip['ip'] ?></td>
          <td><?= $ip['fecha_bloqueo'] ?></td>
          <td>
            <a href="?ip=<?= $ip['ip'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Desbloquear esta IP?')">
              Desbloquear
            </a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <a href="../dashboard.php" class="btn btn-secondary mt-3">Volver al Dashboard</a>
</body>
</html>
