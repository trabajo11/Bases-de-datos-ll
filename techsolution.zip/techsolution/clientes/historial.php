<?php
include '../db.php';
$id = $_GET['id'];

$cliente = $conn->query("SELECT * FROM clientes WHERE id=$id")->fetch_assoc();
$reparaciones = $conn->query("SELECT * FROM reparaciones WHERE cliente_id = $id");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Historial de <?= $cliente['nombre'] ?></title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h2>Historial de Reparaciones: <?= $cliente['nombre'] ?></h2>
  <a href="listar.php" class="btn btn-secondary mb-3">Volver</a>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Dispositivo</th>
        <th>Problema</th>
        <th>Estado</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
      <?php while($r = $reparaciones->fetch_assoc()): ?>
        <tr>
          <td><?= $r['dispositivo'] ?></td>
          <td><?= $r['problema'] ?></td>
          <td><?= $r['estado'] ?></td>
          <td><?= $r['fecha_registro'] ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
