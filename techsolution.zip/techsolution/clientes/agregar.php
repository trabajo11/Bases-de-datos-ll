<?php
include '../db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $tel = $_POST['telefono'];
    $email = $_POST['email'];
    $conn->query("INSERT INTO clientes (nombre, telefono, email) VALUES ('$nombre', '$tel', '$email')");
    header("Location: listar.php");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Cliente</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h2>Agregar Cliente</h2>
  <form method="POST">
    <input type="text" name="nombre" class="form-control mb-3" placeholder="Nombre" required>
    <input type="text" name="telefono" class="form-control mb-3" placeholder="Teléfono">
    <input type="email" name="email" class="form-control mb-3" placeholder="Email">
    <button class="btn btn-success">Guardar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
  </form>
</body>
</html>
