<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}
include 'db.php';

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

// Estadísticas
$total = $conn->query("SELECT COUNT(*) as total FROM reparaciones")->fetch_assoc()['total'];
$pendientes = $conn->query("SELECT COUNT(*) as total FROM reparaciones WHERE estado='Pendiente'")->fetch_assoc()['total'];
$completadas = $conn->query("SELECT COUNT(*) as total FROM reparaciones WHERE estado='Completado'")->fetch_assoc()['total'];
$enproceso = $conn->query("SELECT COUNT(*) as total FROM reparaciones WHERE estado='En proceso'")->fetch_assoc()['total'];

// Reparaciones recientes
$ultimas = $conn->query("
    SELECT r.*, c.nombre AS cliente_nombre
    FROM reparaciones r
    LEFT JOIN clientes c ON r.cliente_id = c.id
    ORDER BY r.fecha_registro DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Tech Solution</title>
  <!-- Bootstrap CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      display: flex;
      min-height: 100vh;
      font-family: 'Segoe UI', sans-serif;
    }
    .sidebar {
      width: 220px;
      background: #343a40;
      padding-top: 20px;
    }
    .sidebar a {
      color: #ccc;
      padding: 15px;
      display: block;
      text-decoration: none;
    }
    .sidebar a:hover, .sidebar a.active {
      background-color: #495057;
      color: #fff;
    }
    .main-content {
      flex: 1;
      padding: 30px;
      background: #f8f9fa;
    }
    .card h5 {
      font-size: 1rem;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <a href="dashboard.php" class="active"><i class="fas fa-home"></i> Inicio</a>
    <a href="acciones/agregar.php"><i class="fas fa-plus-circle"></i> Nueva Reparación</a>
    <a href="clientes/listar.php"><i class="fas fa-users"></i> Clientes</a>
    <?php if ($rol === 'admin'): ?>
    <a href="admin/desbloquear_ip.php"><i class="fas fa-unlock"></i> Desbloquear IP</a>
    <?php endif; ?>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Salir</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <h3 class="mb-4">Bienvenido, <?= $usuario ?> (<?= $rol ?>)</h3>

    <!-- Tarjetas -->
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <div class="card border-primary shadow-sm">
          <div class="card-body text-center">
            <h5><i class="fas fa-wrench text-primary"></i> Total Reparaciones</h5>
            <h3><?= $total ?></h3>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card border-warning shadow-sm">
          <div class="card-body text-center">
            <h5><i class="fas fa-clock text-warning"></i> Pendientes</h5>
            <h3><?= $pendientes ?></h3>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card border-info shadow-sm">
          <div class="card-body text-center">
            <h5><i class="fas fa-cogs text-info"></i> En Proceso</h5>
            <h3><?= $enproceso ?></h3>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card border-success shadow-sm">
          <div class="card-body text-center">
            <h5><i class="fas fa-check text-success"></i> Completadas</h5>
            <h3><?= $completadas ?></h3>
          </div>
        </div>
      </div>
    </div>

    <!-- Gráfico -->
    <div class="card mb-4">
      <div class="card-header bg-dark text-white">Estadísticas de Reparaciones</div>
      <div class="card-body">
        <canvas id="graficoReparaciones"></canvas>
      </div>
    </div>

    <!-- Tabla de Reparaciones -->
    <div class="card">
      <div class="card-header bg-primary text-white">Últimas Reparaciones</div>
      <div class="card-body table-responsive">
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Cliente</th>
              <th>Dispositivo</th>
              <th>Problema</th>
              <th>Estado</th>
              <th>Fecha</th>
            </tr>
          </thead>
          <tbody>
            <?php while($r = $ultimas->fetch_assoc()): ?>
            <tr>
              <td><?= $r['id'] ?></td>
              <td><?= $r['cliente_nombre'] ?? 'Sin cliente' ?></td>
              <td><?= $r['dispositivo'] ?></td>
              <td><?= $r['problema'] ?></td>
              <td><?= $r['estado'] ?></td>
              <td><?= $r['fecha_registro'] ?></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Seguridad (Admin) -->
    <?php if ($rol === 'admin'): ?>
    <div class="card mt-4">
      <div class="card-header bg-danger text-white">Intentos de Acceso</div>
      <div class="card-body table-responsive">
        <table class="table table-sm table-bordered">
          <thead class="table-dark">
            <tr>
              <th>IP</th>
              <th>Usuario</th>
              <th>Éxito</th>
              <th>Fecha</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $logs = $conn->query("SELECT * FROM intentos_login ORDER BY fecha DESC LIMIT 10");
            while ($l = $logs->fetch_assoc()):
            ?>
            <tr>
              <td><?= $l['ip'] ?></td>
              <td><?= $l['username'] ?></td>
              <td><?= $l['exito'] ? '✔️' : '❌' ?></td>
              <td><?= $l['fecha'] ?></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Bootstrap JS (CDN) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Chart: Estadísticas -->
  <script>
    const ctx = document.getElementById('graficoReparaciones');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Pendientes', 'En Proceso', 'Completadas'],
        datasets: [{
          label: 'Cantidad',
          data: [<?= $pendientes ?>, <?= $enproceso ?>, <?= $completadas ?>],
          backgroundColor: ['#ffc107', '#17a2b8', '#28a745']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          title: { display: true, text: 'Resumen del Taller' }
        }
      }
    });
  </script>
</body>
</html>
