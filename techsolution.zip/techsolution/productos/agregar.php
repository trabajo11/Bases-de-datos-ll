<?php
include '../db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = $_POST['nombre'];
  $descripcion = $_POST['descripcion'];
  $precio = $_POST['precio'];
  $stock = $_POST['stock'];

  $stmt = $conn->prepare("INSERT INTO productos (nombre, descripcion, precio, stock) VALUES (?, ?, ?, ?)");
  $stmt->bind_param("ssdi", $nombre, $descripcion, $precio, $stock);
  $stmt->execute();

  header("Location: listar.php");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Producto</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h3>Agregar Nuevo Producto</h3>
  <form method="POST">
    <input type="text" name="nombre" class="form-control mb-3" placeholder="Nombre del producto" required>
    <textarea name="descripcion" class="form-control mb-3" placeholder="Descripción" required></textarea>
    <input type="number" name="precio" class="form-control mb-3" step="0.01" placeholder="Precio" required>
    <input type="number" name="stock" class="form-control mb-3" placeholder="Stock inicial" required>
    <button class="btn btn-success">Guardar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
  </form>
</body>
</html>
