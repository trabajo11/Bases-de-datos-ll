<?php
include '../db.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = $_POST['nombre'];
  $descripcion = $_POST['descripcion'];
  $precio = $_POST['precio'];
  $stock = $_POST['stock'];

  $stmt = $conn->prepare("UPDATE productos SET nombre=?, descripcion=?, precio=?, stock=? WHERE id=?");
  $stmt->bind_param("ssdii", $nombre, $descripcion, $precio, $stock, $id);
  $stmt->execute();

  header("Location: listar.php");
}

$producto = $conn->query("SELECT * FROM productos WHERE id=$id")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Producto</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h3>Editar Producto</h3>
  <form method="POST">
    <input type="text" name="nombre" class="form-control mb-3" value="<?= $producto['nombre'] ?>" required>
    <textarea name="descripcion" class="form-control mb-3" required><?= $producto['descripcion'] ?></textarea>
    <input type="number" name="precio" class="form-control mb-3" step="0.01" value="<?= $producto['precio'] ?>" required>
    <input type="number" name="stock" class="form-control mb-3" value="<?= $producto['stock'] ?>" required>
    <button class="btn btn-primary">Actualizar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
  </form>
</body>
</html>
