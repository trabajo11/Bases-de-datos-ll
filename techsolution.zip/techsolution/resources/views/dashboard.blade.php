@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="container">
    <h1 class="mb-4">Dashboard Principal</h1>

    @if($estadisticas)
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5 class="card-title">Total Reparaciones</h5>
                    <p class="card-text fs-2">{{ $estadisticas->total_reparaciones ?? 0 }}</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h5 class="card-title">Pendientes</h5>
                    <p class="card-text fs-2">{{ $estadisticas->pendientes ?? 0 }}</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5 class="card-title">En Proceso</h5>
                    <p class="card-text fs-2">{{ $estadisticas->en_proceso ?? 0 }}</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5 class="card-title">Completadas</h5>
                    <p class="card-text fs-2">{{ $estadisticas->completadas ?? 0 }}</p>
                </div>
            </div>
        </div>
    </div>
     <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Clientes Activos</h5>
                    <p class="card-text fs-2">{{ $estadisticas->total_clientes ?? 0 }}</p>
                </div>
            </div>
        </div>
         <div class="col-md-3">
            <div class="card text-white bg-danger">
                <div class="card-body">
                    <h5 class="card-title">Productos Stock Bajo</h5>
                    <p class="card-text fs-2">{{ $estadisticas->productos_stock_bajo ?? 0 }}</p>
                    @if(($estadisticas->productos_stock_bajo ?? 0) > 0)
                        <a href="{{-- route('productos.stock.bajo') --}}" class="small-box-footer text-white">Ver detalles <i class="fas fa-arrow-circle-right"></i></a>
                    @endif
                </div>
            </div>
        </div>
    </div>
    @else
    <p>No se pudieron cargar las estadísticas.</p>
    @endif

    @if(isset($productosBajoStock) && $productosBajoStock->count() > 0)
    <div class="mt-5">
        <h3>Productos con Stock Bajo</h3>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Stock Actual</th>
                        <th>Stock Mínimo</th>
                        <th>Categoría</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($productosBajoStock as $producto)
                    <tr>
                        <td>{{ $producto->codigo }}</td>
                        <td>{{ $producto->nombre }}</td>
                        <td><span class="badge bg-danger">{{ $producto->stock }}</span></td>
                        <td>{{ $producto->stock_minimo }}</td>
                        <td>{{ $producto->categoria }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @endif

    </div>
@endsection