@extends('layouts.app')

@section('title', 'Consultar Estado de Reparación')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Consulta el Estado de tu Reparación</h4>
            </div>
            <div class="card-body">
                <p class="lead text-center">Ingresa tu número de reparación o documento de identidad.</p>
                <form method="POST" action="{{ route('public.repair.status.check') }}">
                    @csrf
                    <div class="mb-3">
                        <label for="tipo_busqueda" class="form-label">Buscar por:</label>
                        <select class="form-select" id="tipo_busqueda" name="tipo_busqueda" required>
                            <option value="numero_reparacion" {{ (old('tipo_busqueda', $tipo_busqueda ?? '') == 'numero_reparacion') ? 'selected' : '' }}>Número de Reparación</option>
                            <option value="documento_cliente" {{ (old('tipo_busqueda', $tipo_busqueda ?? '') == 'documento_cliente') ? 'selected' : '' }}>Documento del Cliente (DNI)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="termino" class="form-label">Número / Documento:</label>
                        <input type="text" class="form-control @error('termino') is-invalid @enderror" id="termino" name="termino" value="{{ old('termino', $termino ?? '') }}" required>
                        @error('termino')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Consultar</button>
                    </div>
                </form>

                @if(isset($reparacion) && $reparacion)
                    <hr class="my-4">
                    <h5 class="text-success">¡Reparación Encontrada!</h5>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">ID Reparación:</th>
                                <td>{{ $reparacion->id }}</td>
                            </tr>
                            <tr>
                                <th scope="row">Cliente:</th>
                                <td>{{ $reparacion->cliente_nombre ?? 'N/A' }}</td> </tr>
                            <tr>
                                <th scope="row">Dispositivo:</th>
                                <td>{{ $reparacion->dispositivo }} {{ $reparacion->marca }} {{ $reparacion->modelo }}</td>
                            </tr>
                            <tr>
                                <th scope="row">Problema Reportado:</th>
                                <td>{{ $reparacion->problema }}</td>
                            </tr>
                            <tr>
                                <th scope="row">Estado Actual:</th>
                                <td><span class="badge bg-info fs-6">{{ $reparacion->estado }}</span></td>
                            </tr>
                             <tr>
                                <th scope="row">Fecha de Registro:</th>
                                <td>{{ \Carbon\Carbon::parse($reparacion->fecha_registro)->format('d/m/Y H:i') }}</td>
                            </tr>
                            @if($reparacion->fecha_finalizacion)
                            <tr>
                                <th scope="row">Fecha de Finalización:</th>
                                <td>{{ \Carbon\Carbon::parse($reparacion->fecha_finalizacion)->format('d/m/Y H:i') }}</td>
                            </tr>
                            @endif
                            </tbody>
                    </table>
                @elseif(isset($not_found) && $not_found)
                    <hr class="my-4">
                    <div class="alert alert-warning text-center">
                        No se encontró ninguna reparación con el término "{{ $termino }}". Por favor, verifica los datos e intenta nuevamente.
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection