<div class="sidebar">
  <a href="dashboard.php" class="active"><i class="fas fa-home"></i> Inicio</a>
  <a href="acciones/agregar.php"><i class="fas fa-plus-circle"></i> Nueva Reparación</a>
  <a href="clientes/listar.php"><i class="fas fa-users"></i> Clientes</a>
  <?php if ($_SESSION['rol'] === 'admin'): ?>
  <a href="admin/desbloquear_ip.php"><i class="fas fa-unlock"></i> Desbloquear IP</a>
  <?php endif; ?>
  <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Salir</a>
</div>
