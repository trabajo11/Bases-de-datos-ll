<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reparacion extends Model
{
    use HasFactory;

    protected $table = 'reparaciones'; // Especifica el nombre de la tabla si no sigue la convención de Laravel

    // Laravel maneja created_at y updated_at por defecto si las columnas existen.
    // Si usas 'fecha_registro' como tu 'created_at' y no tienes 'updated_at', puedes configurarlo:
    const CREATED_AT = 'fecha_registro';
    const UPDATED_AT = null; // O el nombre de tu columna de actualización si la tienes

    protected $fillable = [
        'cliente_id',
        'cliente', // Nombre del cliente si no está registrado
        'dispositivo',
        'marca',
        'modelo',
        'numero_serie',
        'problema',
        'diagnostico',
        'solucion',
        'estado',
        'prioridad',
        'fecha_inicio',
        'fecha_finalizacion',
        'fecha_entrega',
        'tecnico_asignado',
        'costo_mano_obra',
        'costo_total',
        'observaciones',
        'garantia_dias',
    ];

    // Define las conversiones de tipos para campos específicos
    protected $casts = [
        'fecha_registro' => 'datetime',
        'fecha_inicio' => 'datetime',
        'fecha_finalizacion' => 'datetime',
        'fecha_entrega' => 'datetime',
        'costo_mano_obra' => 'decimal:2',
        'costo_total' => 'decimal:2',
    ];

    // Relaciones Eloquent
    public function clienteRegistrado()
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }

    public function tecnico()
    {
        return $this->belongsTo(Usuario::class, 'tecnico_asignado');
    }

    public function productos()
    {
        // Si reparacion_productos es un modelo pivot explícito
        return $this->hasMany(ReparacionProducto::class);
        // O si es una tabla pivot para una relación muchos-a-muchos directa:
        // return $this->belongsToMany(Producto::class, 'reparacion_productos')
        //              ->withPivot('cantidad', 'precio_unitario', 'subtotal')
        //              ->withTimestamps(); // Si tienes timestamps en la tabla pivot
    }

    public function historial()
    {
        return $this->hasMany(ReparacionHistorial::class);
    }

    public function factura()
    {
        return $this->hasOne(Factura::class);
    }
}