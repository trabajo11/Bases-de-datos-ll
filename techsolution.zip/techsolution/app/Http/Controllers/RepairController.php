<?php

namespace App\Http\Controllers;

use App\Models\Reparacion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RepairController extends Controller
{
    // ... otros métodos CRUD generados por --resource (index, create, store, show, edit, update, destroy)

    public function index()
    {
        // Ejemplo: Muestra todas las reparaciones usando la vista
        $reparaciones = DB::table('vista_reparaciones_completa')->orderBy('fecha_registro', 'desc')->paginate(15);
        return view('reparaciones.index', compact('reparaciones'));
    }

    public function search(Request $request)
    {
        $termino = $request->input('termino_busqueda');
        if (!$termino) {
            return redirect()->route('reparaciones.index');
        }

        // Llama al procedimiento almacenado buscar_reparaciones
        $reparaciones = DB::select('CALL buscar_reparaciones(?)', [$termino]);

        return view('reparaciones.index', compact('reparaciones', 'termino'));
    }

    // ... Implementa los demás métodos CRUD (create, store, show, edit, update, destroy)
    // usando el modelo Reparacion y validando los datos.
    // Por ejemplo, para el 'store':
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'cliente_id' => 'nullable|exists:clientes,id',
            'cliente' => 'required_without:cliente_id|string|max:100',
            'dispositivo' => 'required|string|max:100',
            'marca' => 'nullable|string|max:50',
            'modelo' => 'nullable|string|max:50',
            'problema' => 'required|string',
            'estado' => 'nullable|string|in:Pendiente,En proceso,Esperando repuesto,Completado,Entregado,Cancelado', // Enum values from reparaciones table
            'prioridad' => 'nullable|string|in:Baja,Media,Alta,Urgente', // Enum values from reparaciones table
            // ... más validaciones para otros campos
        ]);

        // Los triggers se encargarán de 'costo_total' si añades productos y 'historial_estado_reparacion'
        $reparacion = Reparacion::create($validatedData);

        return redirect()->route('reparaciones.show', $reparacion->id)
                         ->with('success', 'Reparación registrada exitosamente.');
    }
}