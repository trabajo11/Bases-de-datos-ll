<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; // Para usar query builder o vistas directamente
use App\Models\Reparacion; // Opcional si usas el modelo con la vista

class PublicRepairStatusController extends Controller
{
    public function showForm()
    {
        return view('public.repair_status_check');
    }

    public function checkStatus(Request $request)
    {
        $request->validate([
            'tipo_busqueda' => 'required|string|in:numero_reparacion,documento_cliente',
            'termino' => 'required|string|max:100',
        ]);

        $tipoBusqueda = $request->input('tipo_busqueda');
        $termino = $request->input('termino');
        $reparacion = null;

        // Usando la vista vista_reparaciones_completa
        $query = DB::table('vista_reparaciones_completa');

        if ($tipoBusqueda === 'numero_reparacion') {
            // Asumiendo que el 'id' de la reparación es el número de reparación
            $reparacion = $query->where('id', $termino)->first();
        } elseif ($tipoBusqueda === 'documento_cliente') {
            // Necesitaríamos saber si el DNI está en la vista directamente
            // o si necesitamos un JOIN adicional.
            // Por ahora, la vista_reparaciones_completa no tiene DNI explícitamente.
            // Vamos a asumir que 'cliente_nombre' podría usarse o necesitarías
            // modificar la vista o hacer un join a la tabla clientes.
            // Este es un ejemplo si el DNI estuviera en la vista como 'cliente_dni':
            // $reparacion = $query->where('cliente_dni', $termino)->first();

            // Si no tienes DNI en la vista, tendrías que buscar en la tabla clientes y luego las reparaciones:
            // $cliente = \App\Models\Cliente::where('dni', $termino)->first();
            // if ($cliente) {
            //    $reparacion = $query->where('cliente_nombre', $cliente->nombre) // O mejor por cliente_id si la vista lo permite bien
            //                         ->orderBy('fecha_registro', 'desc')
            //                         ->first();
            // }
            // Por ahora, para simplificar y usar la vista directamente, vamos a asumir
            // que el usuario podría buscar por nombre de cliente si la vista lo permite en su `cliente_nombre`
            // O, si el DNI está en la tabla 'clientes' y 'cliente_id' está en 'vista_reparaciones_completa'
            $cliente = \App\Models\Cliente::where('dni', $termino)->first(); // Busca en tabla clientes
            if ($cliente) {
                $reparacion = $query->where('cliente_nombre', $cliente->nombre) // Asocia por nombre
                                     // O mejor, si la vista tiene `cliente_id` directo de la tabla `clientes`
                                     // ->where('cliente_id_en_vista', $cliente->id)
                                     ->orderBy('fecha_registro', 'desc')
                                     ->first();
            }
        }

        if ($reparacion) {
            return view('public.repair_status_check', ['reparacion' => $reparacion, 'termino' => $termino]);
        } else {
            return view('public.repair_status_check', ['not_found' => true, 'termino' => $termino]);
        }
    }
}